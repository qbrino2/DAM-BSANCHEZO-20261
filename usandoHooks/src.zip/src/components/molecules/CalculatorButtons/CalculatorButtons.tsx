import React from 'react';
import { View } from 'react-native';
import Button from '../../atoms/Button';

interface Props {
  onPress: (value: string) => void;
}

const CalculatorButtons = ({ onPress }: Props) => {
  const buttons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['0', 'C', '=', '+'],
  ];

  return (
    <>
      {buttons.map((row, index) => (
        <View key={index} style={{ flexDirection: 'row' }}>
          {row.map((btn) => (
            <Button
              key={btn}
              label={btn}
              onPress={() => onPress(btn)}
            />
          ))}
        </View>
      ))}
    </>
  );
};

export default CalculatorButtons;