import { StyleSheet } from 'react-native';
import { colors, spacing } from '../../../themes';

export default StyleSheet.create({
  container: {
    padding: spacing.md,
    backgroundColor: colors.background,
    alignItems: 'flex-end',
  },
  text: {
    color: colors.white,
    fontSize: 32,
  },
});