import React from 'react';
import { View, Text } from 'react-native';
import styles from './CalculatorDisplay.style';

interface Props {
  value: string;
}

const CalculatorDisplay = ({ value }: Props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>{value || '0'}</Text>
    </View>
  );
};

export default CalculatorDisplay;