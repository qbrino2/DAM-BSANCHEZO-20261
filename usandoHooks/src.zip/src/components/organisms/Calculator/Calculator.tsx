import React, { useState } from 'react';
import { View } from 'react-native';

import CalculatorDisplay from '../../molecules/CalculatorDisplay';
import CalculatorButtons from '../../molecules/CalculatorButtons';

const Calculator = () => {
  const [value, setValue] = useState('');

  const handlePress = (input: string) => {
    // Limpiar
    if (input === 'C') {
      setValue('');
      return;
    }

    // Calcular resultado
    if (input === '=') {
      try {
        setValue(eval(value).toString());
      } catch {
        setValue('Error');
      }
      return;
    }

    // Agregar números y operadores
    setValue(value + input);
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center' }}>
      <CalculatorDisplay value={value} />
      <CalculatorButtons onPress={handlePress} />
    </View>
  );
};

export default Calculator;