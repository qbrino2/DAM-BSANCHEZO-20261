import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import styles from './Button.style';

interface Props {
  label: string;
  onPress: () => void;
}

const Button = ({ label, onPress }: Props) => {
  return (
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <Text style={styles.text}>{label}</Text>
    </TouchableOpacity>
  );
};

export default Button;