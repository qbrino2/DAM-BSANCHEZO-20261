import { StyleSheet } from 'react-native';
import { colors, spacing } from '../../../themes';

export default StyleSheet.create({
  button: {
    flex: 1,
    margin: spacing.xs,
    padding: spacing.md,
    backgroundColor: colors.primary,
    alignItems: 'center',
    borderRadius: 5,
  },
  text: {
    color: colors.white,
    fontSize: 18,
  },
});