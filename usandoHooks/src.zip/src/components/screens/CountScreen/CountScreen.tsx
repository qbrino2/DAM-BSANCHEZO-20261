import React from 'react';
import { SafeAreaView } from 'react-native';
import Calculator from '../../organisms/Calculator';

const CountScreen = () => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Calculator />
    </SafeAreaView>
  );
};

export default CountScreen;