import React from 'react';
import CountScreen from '../src/components/screens/CountScreen/CountScreen';

const App = () => {
  return <CountScreen />;
};

export default App;